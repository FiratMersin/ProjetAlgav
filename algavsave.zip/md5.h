#ifndef MD5_H
#define MD5_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

bigInt *md5(char *data, unsigned int dataSize);

#endif
